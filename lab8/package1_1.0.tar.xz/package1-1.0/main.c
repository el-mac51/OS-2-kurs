#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;
    printf("Enter two numbers!\n");
    scanf("%d", &a);
    scanf("%d", &b);
    printf("The result will be on the screen:\n");
    printf("%d", a+b);
    return 0;
}
